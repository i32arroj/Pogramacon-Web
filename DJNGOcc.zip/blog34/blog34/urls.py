"""blog34 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from publicaciones import views
from publicaciones.views import *
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    url(r'^$', views.listarPublicaciones, name='Listar publicaciones'),
    url(r'^publicacion/(?P<publicacion_id>\d+)', views.verPublicacion, name='Ver publicacion'),
    url(r'^crearPublicacion/', views.crearPublicacion, name='Crear publicacion'),
    url(r'^modificarPublicacion/(?P<publicacion_id>\d+)', views.modificarPublicacion, name='Modificar publicacion'),
    url(r'^borrarPublicacion/(?P<publicacion_id>\d+)', views.borrarPublicacion, name='Borrar publicacion'),
    url(r'^buscarPublicaciones/', views.buscarPublicaciones, name='Buscar publicaciones'),

    url(r'^borrarComentario/(?P<comentario_id>\d+)', views.borrarComentario, name='Borrar comentario'),

    url(r'^usuarios/', views.listarUsuarios, name='Listar usuarios'),
    url(r'^usuario/(?P<usuario_id>\d+)', views.verUsuario, name='Ver usuario'),

    url(r'^login/', views.usuarioLogin, name='Login'),
    url(r'^logout/', views.usuarioLogout, name='Logout'),
    url(r'^registro/', views.usuarioRegistro, name='Registro'),

    url(r'^admin/', admin.site.urls),
] + static(settings.STATIC_URL, document_root=settings.STATIC_URL)
