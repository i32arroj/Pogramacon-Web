from __future__ import unicode_literals

from django.db import models
from datetime import datetime
from django.contrib.auth.models import User

# Clase Publicacion del blog
class Publicacion(models.Model):
    titulo = models.CharField(max_length=100)
    fecha = models.DateTimeField(default=datetime.now)
    contenido = models.TextField()
    autor = models.ForeignKey(User,related_name='publicaciones')

    def __unicode__(self):
        return self.titulo

# Clase Comentario del blog
class Comentario(models.Model):
    autor = models.ForeignKey(User, related_name='comentarios')
    publicacion = models.ForeignKey(Publicacion, related_name='comentarios')
    fecha = models.DateTimeField(default=datetime.now)
    contenido = models.TextField()

    def __unicode__(self):
        return self.autor.username + ' [' + self.publicacion.titulo + ']'