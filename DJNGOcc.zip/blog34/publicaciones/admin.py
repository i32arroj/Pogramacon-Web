from django.contrib import admin
from publicaciones.models import Publicacion, Comentario

# Registro de las clases Publicacion y Comentario
admin.site.register(Publicacion)
admin.site.register(Comentario)