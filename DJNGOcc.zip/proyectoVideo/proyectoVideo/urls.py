from django.conf.urls import patterns, include, url
from django.contrib import admin
from videos import views
from videos.views import *
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = patterns('',

    url(r'^$', views.listarVideos, name='Listar Videos'),
    url(r'^video/(?P<video_id>\d+)', views.verVideo, name='Ver Video'),
	"url(r'^video/(?P<video_id>\d+)', views.listarVideos, name='Listar Videos'),
    url(r'^borrarVideo/(?P<video_id>\d+)', views.borrarVideo, name='Borrar Video'),
    url(r'^editarVideo/(?P<video_id>\d+)', views.editarVideo, name='Editar Video'),
    url(r'^subirVideo/', views.subirVideo, name='Subir Video'),
    url(r'^buscarVideos/(?P<video_id>\d+)', views.buscarVideos, name='Buscar Video'),

    url(r'^borrarComentario/(?P<comentario_id>\d+)', views.borrarComentario, name='Borrar Comentario'),

    url(r'^usuarios/', views.listarUsuarios, name='Listar Usuarios'),
    url(r'^usuario/(?P<usuario_id>\d+)', views.verUsuario, name='Ver Usuario'),
    url(r'^editarUsuario/(?P<usuario_id>\d+)', views.editarUsuario, name='Editar Usuario'),

    url(r'^login/', views.usuarioLogin, name='Login'),
    url(r'^registro/', views.usuarioRegistro, name='Registro'),
    url(r'^logout/', views.usuarioLogout, name='Logout'),

    url(r'^admin/', include(admin.site.urls)),
) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) + static(settings.STATIC_URL, document_root=settings.STATIC_URL)
