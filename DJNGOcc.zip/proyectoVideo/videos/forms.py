from django.contrib.auth.models import User
from django.forms import ModelForm
from django import forms
from django.contrib.auth.forms import UserCreationForm
from videos.models import Video, Comentario

class SubirVideoForm(forms.ModelForm):
    class Meta:
        model=Video
        fields=['nombre','categoria','videoSubido','descripcion']

class EditarVideoForm(forms.ModelForm):
    class Meta:
        model=Video
        fields=['nombre','categoria','descripcion']

class PublicarComentarioForm(forms.ModelForm):
    class Meta:
        model=Comentario
        fields=['contenido']

class AutenticacionForm(forms.ModelForm):
    class Meta:
        model=User
        fields=['username','password']
        widgets={'password': forms.PasswordInput(),}

class EditarUsuarioForm(forms.ModelForm):
    class Meta:
        model=User
        fields=['first_name','last_name','email']

class RegistroForm(UserCreationForm):
    class Meta:
        model=User
        fields=['username','first_name','last_name','email']
