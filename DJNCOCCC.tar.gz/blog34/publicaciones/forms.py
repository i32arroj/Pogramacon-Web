from django import forms
from publicaciones.models import Publicacion, Comentario
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

class PublicacionForm(forms.ModelForm):
    class Meta:
        model = Publicacion
        fields = ['titulo','contenido']

class ComentarioForm(forms.ModelForm):
    class Meta:
        model = Comentario
        fields = ['contenido']

class AutenticacionForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username','password']
        widgets={'password': forms.PasswordInput(),}

class RegistroForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username','email']