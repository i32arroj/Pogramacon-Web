from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.core.paginator import Paginator, InvalidPage, EmptyPage, PageNotAnInteger
from publicaciones.models import Publicacion, Comentario
from django.contrib.auth.models import User
from publicaciones.forms import PublicacionForm, ComentarioForm, AutenticacionForm, RegistroForm

# Funcion que lista todas las publicaciones del blog
def listarPublicaciones(request):
    publicaciones = Publicacion.objects.all().order_by('-fecha')

    paginador = Paginator(publicaciones,3)
    pagina = request.GET.get('page')
    try:
        publicaciones = paginador.page(pagina)
    except PageNotAnInteger:
        publicaciones = paginador.page(1)
    except EmptyPage:
        publicaciones = paginador.page(paginador.num_pages)

    contexto = {'publicaciones':publicaciones,
                'navbar': "publicaciones"}
    return render(request,'listarPublicaciones.html',contexto)

# Funcion que busca publicaciones
def buscarPublicaciones(request):
    if request.GET.has_key('buscar'):
        if request.GET['buscar']:
            publicaciones = Publicacion.objects.filter(titulo__icontains = request.GET['buscar']).order_by('-fecha')
        else:
            return redirect('/')
    else:
        return redirect('/')

    paginador = Paginator(publicaciones,4)
    pagina = request.GET.get('page')
    try:
        publicaciones = paginador.page(pagina)
    except PageNotAnInteger:
        publicaciones = paginador.page(1)
    except EmptyPage:
        publicaciones = paginador.page(paginador.num_pages)

    contexto={'publicaciones':publicaciones,
              'textoBuscado': request.GET['buscar'],
              'navbar': "publicaciones"}

    return render(request,'buscarPublicaciones.html',contexto)


# Funcion que muestra un publicacion especifica del blog
def verPublicacion(request,publicacion_id):
    publicacion = Publicacion.objects.get(pk = publicacion_id)

    if request.method == 'POST':
        formulario = ComentarioForm(request.POST)
        if formulario.is_valid():
            comentario = formulario.save(commit=False)
            comentario.autor = User.objects.get(pk=request.user.id)
            comentario.publicacion = publicacion
            comentario.save()
    else:
        formulario = ComentarioForm()

    contexto = {'publicacion':publicacion,
                'formulario':formulario,
                'navbar': "publicaciones"}
    return render(request,'verPublicacion.html',contexto)

# Funcion para crear una nueva publicacion
@staff_member_required
def crearPublicacion(request):
    if request.method=='POST':
        publicacion = Publicacion()
        formulario = PublicacionForm(request.POST,instance=publicacion)
        if formulario.is_valid():
            publicacionNueva = formulario.save(commit=False)
            publicacionNueva.autor = User.objects.get(pk = request.user.id)
            publicacionNueva.save()
            return redirect('/')
    else:
        formulario = PublicacionForm()
    contexto = {'formulario':formulario,
                'navbar': "crearPublicacion"}
    return render(request, 'crearPublicacion.html', contexto)

# Funcion para modificar una publicacion
@staff_member_required
def modificarPublicacion(request,publicacion_id):
    publicacion = get_object_or_404(Publicacion, pk = publicacion_id)

    if request.method == 'POST':
        formulario = PublicacionForm(request.POST,instance=publicacion)
        if formulario.is_valid():
            formulario.save()
            return redirect('/publicacion/' + publicacion_id)
    else:
        formulario = PublicacionForm(instance=publicacion)
    contexto = {'formulario': formulario,
                'navbar': "publicaciones"}
    return render(request, 'modificarPublicacion.html', contexto)

# Funcion para borrar una publicacion
@staff_member_required
def borrarPublicacion(request,publicacion_id):
    publicacion = get_object_or_404(Publicacion, pk = publicacion_id)

    for comentario in publicacion.comentarios.all():
        comentario.delete()

    publicacion.delete()
    return redirect('/')

# Funcion para borrar un comentario
@staff_member_required
def borrarComentario(request,comentario_id):
    comentario = get_object_or_404(Comentario, pk = comentario_id)
    comentario.delete()
    return redirect(request.META['HTTP_REFERER'])

# Funcion que lista los usuarios registrados
def listarUsuarios(request):
    usuarios = User.objects.all().order_by('-last_login')
    contexto = {'usuarios': usuarios,
                'navbar': "usuarios"}
    return render(request, 'listarUsuarios.html', contexto)

# Funcion que muestra un usuario
def verUsuario(request,usuario_id):
    usuario = User.objects.get(pk = usuario_id)
    contexto = {'usuario':usuario,
                'navbar': "usuario"}
    return render(request,'verUsuario.html',contexto)

# Funcion para iniciar sesion en la pagina
def usuarioLogin(request):
    if request.method=='POST':
        formulario = AutenticacionForm(request.POST)
        if formulario.is_valid:
            usuario = request.POST['username']
            clave = request.POST['password']
            acceso = authenticate(username=usuario, password=clave)
            if acceso is not None:
                if acceso.is_active:
                    login(request,acceso)
                    return redirect('/')
                else:
                    return render(request, 'errorLogin.html')
            else:
                return render(request, 'errorLogin.html')
    else:
        formulario = AutenticacionForm()
    contexto = {'formulario':formulario,
                'navbar': "login"}
    return render(request,'login.html',contexto)

# Funcion para cerrar sesion en la pagina
@login_required(login_url='/login')
def usuarioLogout(request):
    logout(request)
    return redirect('/')

# Funcion para registrarse en la pagina
def usuarioRegistro(request):
    if request.method == 'POST':
        formulario = RegistroForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('/')
    else:
        formulario = RegistroForm()
    contexto = {'formulario':formulario,
                'navbar': "registro"}
    return render(request,'registro.html',contexto)