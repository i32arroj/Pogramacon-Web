# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Comentario',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('contenido', models.TextField()),
                ('fechaPublicacion', models.DateTimeField(default=datetime.datetime.now)),
                ('usuario', models.ForeignKey(related_name=b'comentarios', to=settings.AUTH_USER_MODEL)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Video',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=150)),
                ('categoria', models.CharField(default=b'Cine', max_length=10, choices=[(b'Cine', b'Cine'), (b'Juegos', b'Juegos'), (b'Tecnologia', b'Tecnologia'), (b'Musica', b'Musica'), (b'Otros', b'Otros')])),
                ('videoSubido', models.FileField(upload_to=b'videosSubidos')),
                ('descripcion', models.TextField()),
                ('numeroVisitas', models.IntegerField(default=0)),
                ('fechaSubida', models.DateTimeField(default=datetime.datetime.now)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='comentario',
            name='video',
            field=models.ForeignKey(related_name=b'comentarios', to='videos.Video'),
            preserve_default=True,
        ),
    ]
