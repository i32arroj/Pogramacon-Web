from __future__ import unicode_literals

from django.db import models
from datetime import datetime
from django.contrib.auth.models import User

class Video(models.Model):

    CATEGORIAS_VIDEO = (
	    ('Cine','Cine'),
	    ('Juegos','Juegos'),
        ('Tecnologia','Tecnologia'),
        ('Musica','Musica'),
	    ('Otros','Otros'),
	)

    nombre=models.CharField(max_length=150)
    categoria=models.CharField(max_length=10,choices=CATEGORIAS_VIDEO,default='Cine')
    videoSubido=models.FileField(upload_to='videosSubidos')
    descripcion=models.TextField()
    numeroVisitas=models.IntegerField(default=0)
    fechaSubida=models.DateTimeField(default=datetime.now)
    usuario=models.ForeignKey(User, related_name='Videos')

    def __unicode__(self):
        return self.nombre

class Comentario(models.Model):
    usuario=models.ForeignKey(User, related_name='comentarios')
    video=models.ForeignKey(Video, related_name='comentarios')
    contenido=models.TextField()
    fechaPublicacion=models.DateTimeField(default=datetime.now)

    def __unicode__(self):
        return self.usuario + " [" + self.fechaPublicacion + "]"
