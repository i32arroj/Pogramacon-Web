from django.shortcuts import render, redirect, get_object_or_404
from videos.models import Video, Comentario
from videos.forms import *
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, InvalidPage, EmptyPage, PageNotAnInteger

def inicio(request):
    contexto={'navbar': "inicio"}
    return render(request,'inicio.html',contexto)

def listarVideos(request):
    videos=Video.objects.all().order_by('-fechaSubida')

    paginador=Paginator(videos,4)
    pagina=request.GET.get('page')
    try:
        videos=paginador.page(pagina)
    except PageNotAnInteger:
        videos=paginador.page(1)
    except EmptyPage:
        videos=paginador.page(paginador.num_pages)

    contexto={'videos':videos,
              'navbar': "videos"}

    return render(request,'videos/listarVideos.html',contexto)

def buscarVideos(request):

    if request.GET.has_key('buscar'):
        if request.GET['buscar']:
            videos=Video.objects.filter(nombre__icontains = request.GET['buscar']).order_by('-fechaSubida')
        else:
            return redirect('/')
    else:
        return redirect('/')

    paginador=Paginator(videos,4)
    pagina=request.GET.get('page')
    try:
        videos=paginador.page(pagina)
    except PageNotAnInteger:
        videos=paginador.page(1)
    except EmptyPage:
        videos=paginador.page(paginador.num_pages)

    contexto={'videos':videos,
              'textoBuscado': request.GET['buscar'],
              'navbar': "videos"}

    return render(request,'videos/buscarVideos.html',contexto)

def verVideo(request,video_id):
    video=Video.objects.get(pk=video_id)
    video.numeroVisitas+=1
    video.save()

    if request.method=='POST':
        formulario=PublicarComentarioForm(request.POST)
        if formulario.is_valid():
            comentarioNuevo=formulario.save(commit=False)
            comentarioNuevo.usuario=User.objects.get(pk=request.user.id)
            comentarioNuevo.video=video
            comentarioNuevo.save()
    else:
        formulario=PublicarComentarioForm()

    contexto={'video':video,
              'formulario':formulario,
              'navbar': "videos"}
    return render(request,'videos/verVideo.html',contexto)

@login_required(login_url='/login')
def borrarComentario(request,comentario_id):
    comentario=Comentario.objects.get(pk=comentario_id)
    usuarioLogueado=User.objects.get(pk=request.user.id)

    if usuarioLogueado==comentario.video.usuario or usuarioLogueado==comentario.usuario:
        comentario.delete()

    return redirect(request.META['HTTP_REFERER'])

@login_required(login_url='/login')
def borrarVideo(request,video_id):
    video=Video.objects.get(pk=video_id)
    usuarioLogueado=User.objects.get(pk=request.user.id)

    if usuarioLogueado==video.usuario:
        for comentario in video.comentarios.all():
            comentario.delete()
        video.delete()
    return redirect('/')

@login_required(login_url='/login')
def editarVideo(request,video_id):
    video = get_object_or_404(Video, pk = video_id)
    usuarioLogueado=User.objects.get(pk=request.user.id)

    if usuarioLogueado==video.usuario:
        if request.method=='POST':
            formulario = EditarVideoForm(request.POST,instance=video)
            if formulario.is_valid():
                formulario.save()
                return redirect('/video/' + video_id)
        else:
            formulario = EditarVideoForm(instance=video)
        contexto={'formulario':formulario,
                  'navbar': "videos"}
        return render(request,'videos/editarVideo.html',contexto)
    else:
        return redirect('/')

@login_required(login_url='/login')
def subirVideo(request):
    if request.method=='POST':
        formulario=SubirVideoForm(request.POST,request.FILES)
        if formulario.is_valid():
            videoNuevo=formulario.save(commit=False)
            videoNuevo.usuario=User.objects.get(pk=request.user.id)
            videoNuevo.save()
            return redirect('/')
    else:
        formulario=SubirVideoForm()
    contexto={'formulario':formulario,
              'navbar': "subirVideo"}
    return render(request,'videos/subirVideo.html',contexto)

def listarUsuarios(request):
    usuarios=User.objects.all().order_by('-last_login')

    paginador=Paginator(usuarios,4)
    pagina=request.GET.get('page')
    try:
        usuarios=paginador.page(pagina)
    except PageNotAnInteger:
        usuarios=paginador.page(1)
    except EmptyPage:
        usuarios=paginador.page(paginador.num_pages)

    contexto={'usuarios':usuarios,
              'navbar': "usuarios"}
    return render(request,'usuarios/listarUsuarios.html',contexto)

def verUsuario(request,usuario_id):
    usuario=User.objects.get(pk=usuario_id)
    contexto={'usuario':usuario,
              'navbar': "usuario"}
    return render(request,'usuarios/verUsuario.html',contexto)

@login_required(login_url='/login')
def editarUsuario(request,usuario_id):
    usuarioViendo = get_object_or_404(User, pk = usuario_id)
    usuarioLogueado=User.objects.get(pk=request.user.id)

    if usuarioLogueado==usuarioViendo:
        if request.method=='POST':
            formulario = EditarUsuarioForm(request.POST,instance=usuarioViendo)
            if formulario.is_valid():
                formulario.save()
                return redirect('/usuario/' + usuario_id)
        else:
            formulario = EditarUsuarioForm(instance=usuarioViendo)
        contexto={'formulario':formulario,
                  'navbar': "usuario"}
        return render(request,'usuarios/editarUsuario.html',contexto)
    else:
        return redirect('/')

def usuarioLogin(request):
    if request.method=='POST':
        formulario=AutenticacionForm(request.POST)
        if formulario.is_valid:
            usuario=request.POST['username']
            clave=request.POST['password']
            acceso=authenticate(username=usuario, password=clave)
            if acceso is not None:
                if acceso.is_active:
                    login(request,acceso)
                    return redirect('/')
                else:
                    return render(request, 'errorLogin.html')
            else:
                return render(request, 'errorLogin.html')
    else:
        formulario=AutenticacionForm()
    contexto={'formulario':formulario,
              'navbar': "login"}
    return render(request,'login.html',contexto)

@login_required(login_url='/login')
def usuarioLogout(request):
    logout(request)
    return redirect('/')

def usuarioRegistro(request):
    if request.method=='POST':
        formulario=RegistroForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('/')
    else:
        formulario=RegistroForm()
    contexto={'formulario':formulario,
              'navbar': "registro"}
    return render(request,'registro.html',contexto)