from django.contrib import admin
from Entregas.models import *


admin.site.register(Destinatario)
admin.site.register(Paquete)
admin.site.register(Ruta)
