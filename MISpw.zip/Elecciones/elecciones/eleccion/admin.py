from django.contrib import admin
from eleccion.models import *
# Register your models here.

admin.site.register(circunscripcion)
admin.site.register(mesa)
admin.site.register(partidos)
