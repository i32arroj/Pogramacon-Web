"""AVideos URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""

from django.conf.urls import include, url
from django.contrib import admin
from subidas import views
from subidas.views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
	url(r'^$', views.listarVideos, name = "listar videos"),
	url(r'^Video/(?P<Video_id>\d+)', views.verVideo, name = "ver video"),
	url(r'^video/(?P<Video_id>\d+)', views.verVideo, name = "ver video"),    
	url(r'^subirVideo/', views.subirVideo, name='Subir Video'),
	url(r'^buscarVideos/', views.buscarVideos, name='Buscar Video'),
	url(r'^buscarEtiquetas/', views.buscarEtiquetas, name='Buscar Etiquetas'),
	url(r'^misVideos/', views.misVideos, name='Mis Videos'),
	url(r'^borrarVideo/(?P<video_id>\d+)', views.borrarVideo, name='Borrar Video'),	
	url(r'^editarVideo/(?P<video_id>\d+)', views.editarVideo, name='Editar Video'),	

	url(r'^admin/', admin.site.urls),
	url(r'^registro/', views.usuarioRegistro, name='Registro'),
	url(r'^login/', views.usuarioLogin, name='Login'),
	url(r'^logout/', views.usuarioLogout, name='Logout'),
	url(r'^usuario/(?P<usuario_id>\d+)', views.verUsuario, name='Ver Usuario'),
	url(r'^editarUsuario/(?P<usuario_id>\d+)', views.editarUsuario, name='Editar Usuario'),
	url(r'^usuarios/', views.listarUsuarios, name='Listar Usuarios')
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) + static(settings.STATIC_URL, document_root=settings.STATIC_URL)
