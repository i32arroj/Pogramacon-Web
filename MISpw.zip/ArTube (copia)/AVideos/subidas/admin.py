from django.contrib import admin

from subidas.models import Video, Comentario

admin.site.register(Video)
admin.site.register(Comentario)
