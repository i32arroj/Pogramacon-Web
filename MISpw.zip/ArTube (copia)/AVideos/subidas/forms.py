from django import forms
from subidas.models import Video, Comentario
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.forms import ModelForm

class SubirVideoForm(forms.ModelForm):
    class Meta:
        model=Video
        fields=['titulo','categoria','contenido','descripcion','etiquetas','Tipo']

class ComentarioForm(forms.ModelForm):
    class Meta:
        model = Comentario
        fields = ['contenido']

class EditarVideoForm(forms.ModelForm):
    class Meta:
        model=Video
        fields=['titulo','categoria','descripcion','etiquetas','Tipo']

class VideoForm(forms.ModelForm):
    class Meta:
        model = Video
        fields = ['titulo','contenido','fecha']

class EditarUsuarioForm(forms.ModelForm):
    class Meta:
        model=User
        fields=['first_name','last_name','email']

class PublicarComentarioForm(forms.ModelForm):
    class Meta:
        model=Comentario
        fields=['contenido']

class RegistroForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username','first_name','last_name','email']

class AutenticacionForm(forms.ModelForm):
    class Meta:
        model=User
        fields=['username','password']
        widgets={'password': forms.PasswordInput(),}
