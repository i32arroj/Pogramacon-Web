from django.shortcuts import render, redirect, get_object_or_404
from django.shortcuts import render
from viajes.models import *
from django.contrib.auth.models import User
from viajes.forms import *
from django.views.generic import ListView, CreateView
# Create your views here.

def listarDestinos(request):
    destinos = destino.objects.all()
    contexto = {'destinos':destinos}
    return render(request,'listarDestinos.html',contexto)

def crearDestino(request):
    if request.method=='POST':
        formulario = DestinoForm(request.POST)
        if formulario.is_valid():
            destinoNuevo = formulario.save(commit=False)
            destinoNuevo.save()
            return redirect('/')
    else:
        formulario = DestinoForm()
    contexto = {'formulario':formulario}
    return render(request, 'addDestino.html', contexto)

def crearViaje(request):
    if request.method=='POST':
        formulario = ViajeForm(request.POST)
        if formulario.is_valid():
            viajeNuevo = formulario.save(commit=False)
            viajeNuevo.save()
            return redirect('/')
    else:
        formulario = ViajeForm()
    contexto = {'formulario':formulario}
    return render(request, 'addViaje.html', contexto)

class crearRuta(CreateView):
	model = ruta
	fields = ['Ruta','Dias','Coste','Destino1','Destino2','Destino3','destinos']
	template_name = 'addRuta.html'
	success_url="/"

def verDestino(request,destino_id):
	dest = destino.objects.get(pk = destino_id)
	contexto = {'dest':dest}
	return render(request,'verDestino.html',contexto)

def verViaje(request,viaje_id):
	viaj = viaje.objects.get(pk = viaje_id)
	contexto = {'viaj':viaj}
	return render(request,'verViaje.html',contexto)

def listarViajes(request):
    viajess = viaje.objects.all()
    contexto = {'viajess':viajess}
    return render(request,'listarViajes.html',contexto)

class listarRutas(ListView):
    model = ruta
    template_name = 'listarRutas.html'

def VerRuta(request,ruta_id):
	rut = ruta.objects.get(pk = ruta_id)
	contexto = {'rut':rut}
	return render(request,'verRuta.html',contexto)
	
