from django import forms
from viajes.models import *

class DestinoForm(forms.ModelForm):
	class Meta:
		model = destino
		fields = ['lugar','pais']

class ViajeForm(forms.ModelForm):
	class Meta:
		model = viaje
		fields = ['Nombre','Dias','Coste','Desplazamiento','destino']

class RutaForm(forms.ModelForm):
	class Meta:
		model = ruta
		fields = ['Ruta','Dias','Coste','destinos']
