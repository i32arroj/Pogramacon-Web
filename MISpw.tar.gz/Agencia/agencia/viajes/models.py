from __future__ import unicode_literals

from django.db import models

# Create your models here.

class destino(models.Model):
	lugar = models.CharField(max_length=100)
	pais = models.CharField(max_length=100)

	def __unicode__(self):
		return self.lugar

class viaje(models.Model):
	Nombre = models.CharField(max_length=100)
	Dias = models.IntegerField(default=0)
	Coste = models.CharField(max_length=100)
	Desplazamiento = models.CharField(max_length=100)
	destino = models.ForeignKey(destino, related_name='sitio')

	def __unicode__(self):
		return self.Nombre

class ruta(models.Model):
	Ruta = models.CharField(max_length=100)
	Dias = models.IntegerField(default=0)
	Coste = models.CharField(max_length=100)
	Destino1 = models.ForeignKey(destino, related_name='sitio1')
	Destino2 = models.ForeignKey(destino, related_name='sitio2')
	Destino3 = models.ForeignKey(destino, related_name='sitio3')
	destinos = models.ManyToManyField(destino)

	def __unicode__(self):
		return self.Ruta
