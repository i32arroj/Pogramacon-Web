from django.contrib import admin
from viajes.models import *
# Register your models here.

admin.site.register(destino)
admin.site.register(viaje)
admin.site.register(ruta)
