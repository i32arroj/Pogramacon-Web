from django.shortcuts import render, redirect, get_object_or_404
from subidas.models import *
from subidas.forms import *
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, InvalidPage, EmptyPage, PageNotAnInteger
from django.contrib.auth.models import User

@login_required(login_url='/login')
def subirVideo(request):
    if request.method=='POST':
        formulario=SubirVideoForm(request.POST,request.FILES)
        if formulario.is_valid():
            videoNuevo=formulario.save(commit=False)
            videoNuevo.usuario=User.objects.get(pk=request.user.id)
            videoNuevo.save()
            return redirect('/')
    else:
        formulario=SubirVideoForm()
    contexto={'formulario':formulario,
              'navbar': "subirVideo"}
    return render(request,'videos/subirVideo.html',contexto)

@login_required(login_url='/login')
def borrarComentario(request,comentario_id):
    comentario=Comentario.objects.get(pk=comentario_id)
    usuarioLogueado=User.objects.get(pk=request.user.id)

    if usuarioLogueado==comentario.video.usuario or usuarioLogueado==comentario.usuario or usuarioLogueado.is_staff:
        comentario.delete()

    return redirect(request.META['HTTP_REFERER'])

def verUsuario(request,usuario_id):
    usuario=User.objects.get(pk=usuario_id)
    contexto={'usuario':usuario,
              'navbar': "usuario"}
    return render(request,'usuarios/verUsuario.html',contexto)

def listarUsuarios(request):
    usuarios=User.objects.all().order_by('-last_login')

    paginador=Paginator(usuarios,4)
    pagina=request.GET.get('page')
    try:
        usuarios=paginador.page(pagina)
    except PageNotAnInteger:
        usuarios=paginador.page(1)
    except EmptyPage:
        usuarios=paginador.page(paginador.num_pages)

    contexto={'usuarios':usuarios,
              'navbar': "usuarios"}
    return render(request,'usuarios/listarUsuarios.html',contexto)

@login_required(login_url='/login')
def editarUsuario(request,usuario_id):
    usuarioViendo = get_object_or_404(User, pk = usuario_id)
    usuarioLogueado=User.objects.get(pk=request.user.id)

    if usuarioLogueado==usuarioViendo or usuarioLogueado=='admin':
        if request.method=='POST':
            formulario = EditarUsuarioForm(request.POST,instance=usuarioViendo)
            if formulario.is_valid():
                formulario.save()
                return redirect('/usuario/' + usuario_id)
        else:
            formulario = EditarUsuarioForm(instance=usuarioViendo)
        contexto={'formulario':formulario,
                  'navbar': "usuario"}
        return render(request,'usuarios/editarUsuario.html',contexto)
    else:
        return redirect('/')

def buscarVideos(request):

    if request.GET.has_key('buscar'):
        if request.GET['buscar']:
            videos=Video.objects.filter(titulo__icontains = request.GET['buscar']).order_by('-fecha')
        else:
            return redirect('/')
    else:
        return redirect('/')

    paginador=Paginator(videos,4)
    pagina=request.GET.get('page')
    try:
        videos=paginador.page(pagina)
    except PageNotAnInteger:
        videos=paginador.page(1)
    except EmptyPage:
        videos=paginador.page(paginador.num_pages)

    contexto={'videos':videos,
              'textoBuscado': request.GET['buscar'],
              'navbar': "videos"}

    return render(request,'videos/buscarVideos.html',contexto)

def buscarEtiquetas(request):

    if request.GET.has_key('buscar'):
        if request.GET['buscar']:
            videos=Video.objects.filter(etiquetas__icontains = request.GET['buscar']).order_by('-fecha')
        else:
            return redirect('/')
    else:
        return redirect('/')

    paginador=Paginator(videos,4)
    pagina=request.GET.get('page')
    try:
        videos=paginador.page(pagina)
    except PageNotAnInteger:
        videos=paginador.page(1)
    except EmptyPage:
        videos=paginador.page(paginador.num_pages)

    contexto={'videos':videos,
              'textoBuscado2': request.GET['buscar'],
              'navbar': "videos"}

    return render(request,'videos/buscarEtiquetas.html',contexto)

def listarVideos(request):
	subidas = Video.objects.all().order_by('-fecha')	
	contexto = {'subidas':subidas}
	return render(request,'listarVideos.html',contexto)

def misVideos(request):
	subidas = Video.objects.all().order_by('-fecha')	
	contexto = {'subidas':subidas}
	return render(request,'videos/misVideos.html',contexto)

def verVideo(request,Video_id):
	video = Video.objects.get(pk = Video_id)
	video.numeroVisitas+=1	
	video.save()
	
	"""if request.method == 'POST':
		formulario = ComentarioForm(request.POST)
       	if formulario.is_valid():
            comentario = formulario.save(commit=False)
            comentario.autor = User.objects.get(pk=request.user.id)
            comentario.publicacion = publicacion
            comentario.save()
    	else:
        	formulario = ComentarioForm()"""
	contexto = {'video':video,
				'navbar': "videos"}
	return render(request,'verVideo.html',contexto)

@login_required(login_url='/login')
def borrarVideo(request,video_id):
    video=Video.objects.get(pk=video_id)
    usuarioLogueado=User.objects.get(pk=request.user.id)

    if usuarioLogueado==video.usuario or usuarioLogueado.is_staff:
        for comentario in video.comentarios.all():
            comentario.delete()
        video.delete()
    return redirect('/')

@login_required(login_url='/login')
def editarVideo(request,video_id):
    video = get_object_or_404(Video, pk = video_id)
    usuarioLogueado=User.objects.get(pk=request.user.id)

    if usuarioLogueado==video.usuario or usuarioLogueado.is_staff:
        if request.method=='POST':
            formulario = EditarVideoForm(request.POST,instance=video)
            if formulario.is_valid():
                formulario.save()
                return redirect('/Video/' + video_id)
        else:
            formulario = EditarVideoForm(instance=video)
        contexto={'formulario':formulario,
                  'navbar': "videos"}
        return render(request,'videos/editarVideo.html',contexto)
    else:
        return redirect('/')

# Funcion para registrarse en la pagina
def usuarioRegistro(request):
    if request.method == 'POST':
        formulario = RegistroForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('/')
    else:
        formulario = RegistroForm()
    contexto = {'formulario':formulario}
    return render(request,'registro.html',contexto)

def usuarioLogin(request):
    if request.method=='POST':
        formulario=AutenticacionForm(request.POST)
        if formulario.is_valid:
            usuario=request.POST['username']
            clave=request.POST['password']
            acceso=authenticate(username=usuario, password=clave)
            if acceso is not None:
                if acceso.is_active:
                    login(request,acceso)
                    return redirect('/')
                else:
                    return render(request, 'usuarios/errorLogin.html')
            else:
                return render(request, 'usuarios/errorLogin.html')
    else:
        formulario=AutenticacionForm()
    contexto={'formulario':formulario,
              'navbar': "login"}
    return render(request,'login.html',contexto)


# Funcion para cerrar sesion en la pagina
@login_required(login_url='/login')
def usuarioLogout(request):
    logout(request)
    return redirect('/')
