from __future__ import unicode_literals

from django.db import models

from datetime import datetime
from django.contrib.auth.models import User

class Video(models.Model):
	CATEGORIAS_VIDEO = (
	    ('Cine','Cine'),
	    ('Juegos','Juegos'),
        ('Tecnologia','Tecnologia'),
        ('Musica','Musica'),
	    ('Otros','Otros'),
	)
	TIPO_VIDEO = (
		('Publico','Publico'),
		('Privado','Privado'),
	)
	
	categoria = models.CharField(max_length=10,choices=CATEGORIAS_VIDEO,default='Cine')
	titulo = models.CharField(max_length = 100)
	fecha = models.DateTimeField(default=datetime.now)
	descripcion=models.TextField()	
	contenido=models.FileField(upload_to='videosSubidos')
	numeroVisitas=models.IntegerField(default=0)
	usuario=models.ForeignKey(User, related_name='videos')
	etiquetas = models.CharField(max_length = 100)
	Tipo = models.CharField(max_length=10,choices=TIPO_VIDEO,default='Publico')
	

	def __unicode__(self):
		return self.titulo

class Comentario(models.Model):
    usuario=models.ForeignKey(User, related_name='comentarios')
    video=models.ForeignKey(Video, related_name='comentarios')
    contenido=models.TextField()
    fechaPublicacion=models.DateTimeField(default=datetime.now)

    def __unicode__(self):
        return self.contenido
