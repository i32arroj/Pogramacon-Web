from django.contrib import admin
from viajes.models import *

admin.site.register(Destino)
admin.site.register(Viaje)
admin.site.register(Ruta)
